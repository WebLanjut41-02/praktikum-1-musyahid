<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1><?php echo $this->session->userdata('username') ?></h1>
</body>
</html>